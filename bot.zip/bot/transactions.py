import requests
import time
from datetime import datetime

from config import get_params
from bot_logging import add_log

phone = get_params('qiwi_phone')
token = get_params('qiwi_token')
rows = get_params('check_last_qiwi_payments')


class Payment:
    user_id: int
    username: str
    comment: str
    amount: int
    time_start: datetime

    # def __init__(self, user_id: int, username: str, comment: str, amount: int = None, product_id=''):
    #     self.user_id = user_id
    #     self.username = username
    #     self.comment = comment
    #     self.amount = amount
    #     self.product_id = product_id
    #     self.time_start = datetime.now()

    def __str__(self):
        return self.comment


class ProductPayment(Payment):
    product_id: int | str

    def __init__(self, user_id: int, username: str, comment: str, amount: int = None, product_id=''):
        self.user_id = user_id
        self.username = username
        self.comment = comment
        self.amount = amount
        self.product_id = product_id
        self.time_start = datetime.now()


class BalancePayment(Payment):
    def __init__(self, user_id: int, username: str, comment: str, amount: int = None):
        self.user_id = user_id
        self.username = username
        self.comment = comment
        self.amount = amount
        self.time_start = datetime.now()


def payment_history_last(custom_rows=None):
    s = requests.Session()
    s.headers['authorization'] = 'Bearer ' + token
    if custom_rows:
        parameters = {'rows': custom_rows, 'nextTxnId': '', 'nextTxnDate': ''}
    else:
        parameters = {'rows': rows, 'nextTxnId': '', 'nextTxnDate': ''}
    try:
        h = s.get('https://edge.qiwi.com/payment-history/v2/persons/' + phone + '/payments', params=parameters)
        # h = False
        if h.status_code == 200:
            return h.json()
        else:
            return {}
    except requests.exceptions.ConnectTimeout:
        pass
    pass


def get_last_payments(row=None):
    payments = payment_history_last(row)['data']
    return_values = []
    for payment in payments:
        if payment['status'] == 'SUCCESS' and payment['sum']['currency'] == 398:
            return_values.append({'comment': payment['comment'], 'sum': payment['sum']['amount']})
    return return_values


def get_payment_url(amount, comment):
    url = f'https://qiwi.com/payment/form/99?amountInteger={amount}' \
          f'&amountFraction=0&currency=398&extra%5B%27comment%27%5D={comment}&extra%5B%27account%27%5D={phone}' \
          f'&blocked%5B0%5D=comment&blocked%5B1%5D=account&blocked%5B2%5D=sum'
    return url


def check_comment(comment: str, row=None):
    payments = get_last_payments(row)
    payed = list(filter(lambda payment: payment['comment'] == comment, payments))
    if payed:
        return payed[0]

    # return {'sum': 100}
    return False


def check_payment(comment: str, amount):
    try:
        payments = get_last_payments()
        # print(payments)
        for payment in payments:
            if comment == payment['comment'] and int(amount) >= payment['sum']:
                return True
        return False
    except Exception:
        return False


def check_token():
    global phone, token, rows
    phone = get_params('qiwi_phone')
    token = get_params('qiwi_token')
    rows = get_params('check_last_qiwi_payments')
    try:
        if payment_history_last('1')['data']:
            return True
    except Exception as ex:
        print('Auth error. Error', ex)
        return False


def send_p2p(sum_p2p):
    s = requests.Session()
    s.headers = {'content-type': 'application/json'}
    s.headers['authorization'] = 'Bearer ' + token
    s.headers['User-Agent'] = 'Android v3.2.0 MKT'
    s.headers['Accept'] = 'application/json'
    postjson = {"id": "", "sum": {"amount": "", "currency": ""},
                "paymentMethod": {"type": "Account", "accountId": "398"}, "comment": "'comment'",
                "fields": {"account": ""}, 'id': str(int(time.time() * 1000))}
    postjson['sum']['amount'] = sum_p2p
    postjson['sum']['currency'] = '398'
    postjson['fields']['account'] = 'to_qiwi'
    res = s.post('https://edge.qiwi.com/sinap/api/v2/terms/99/payments', json=postjson)
    return res.json()


def check_payments(payments):
    accepted_payments = []
    for payment in payments:
        try:
            check_result = check_comment(payment.comment)
            if check_result:
                payment.amount = check_result['sum']
                accepted_payments.append(payment)
        except Exception as ex:
            add_log('Проблема с киви: ' + str(ex))
            time.sleep(1)
        # print(check_result)

    return accepted_payments
    # return list(filter(lambda payment: check_comment(payment.comment), payments))
