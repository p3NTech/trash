import logging
import os
import sys
import types
from random import randint

import aiogram.types
from aiogram import Bot, Dispatcher, executor
from aiogram.dispatcher import FSMContext
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton as InB
from datetime import datetime, timedelta
import asyncio
from atexit import register

from config import *
from config import get_params as setting
from config import KEYBOARDS as KBS
from database import *
from filters import AdminFilter, LengthFilter, DigitFilter
from states import AddProductStates, ChangeMoneys, SingleStates, QuickAddProductStates
from transactions import check_comment, check_token, check_payments, ProductPayment, BalancePayment
from bot_logging import add_log


# from transactions import check_payment, check_token
# from random import randrange


class Stack:
    values = []

    def __init__(self, items=None):
        if items is None:
            items = []
        self.values = items
        # print(self.values)

    def __str__(self):
        return str(self.values)

    def is_empty(self):
        return self == []

    def add(self, item):
        self.values.append(item)

    def remove(self, *items):
        for item in items:
            self.values.remove(item)

    def size(self):
        return len(self.values)

    def has(self, item):
        return item in self.values


class PaymentStack(Stack):
    def has_id(self, user_id):
        for payment in self.values:
            if payment.user_id == user_id:
                return True
        return False


class GiveProductError(Exception):
    params = {}

    def __init__(self, **kwargs):
        self.params = kwargs

    def __str__(self):
        return f'Не получилось выдать товар, {self.params}'


API_TOKEN = setting('api_token', section='Bot Settings')
logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN, parse_mode='HTML')
dp = Dispatcher(bot, storage=MemoryStorage())
add_log('Бот запущен')

# current_payments = PaymentStack([Payment(1321, '12345')])
current_payments = PaymentStack()
booked_products = Stack()
banned_users = Stack()

flood_limit_time = float(setting('flood_limit_time', section='Shop Settings'))
flood_times = int(setting('flood_times', section='Shop Settings'))


def calculate_discount(purchase_count: int):
    if purchase_count != 0 and purchase_count % int(setting('discount_divider')) == 0:
        discount_number = int((purchase_count / int(setting('discount_divider')) % 3))
        if discount_number == 0:
            discount_number = 3
        discount = setting(f'discount{discount_number}')
        return discount
    return 0


def rate_limit(limit: int, key=None):
    def decorator(func):
        setattr(func, 'throttling_rate_limit', limit)
        # setattr(func, 'throttling_rate_limit', 10)
        # if key:
        setattr(func, 'throttling_key', 'key')
        return func

    return decorator


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, key_prefix='antiflood_'):
        self.rate_limit = flood_limit_time
        self.prefix = key_prefix
        super(ThrottlingMiddleware, self).__init__()

    async def on_process_message(self, message: types.Message, data: dict):
        # if check_ban(int(message.from_user.id)):
        #     raise CancelHandler()

        # Get current handler
        handler = current_handler.get()
        # Get dispatcher from context
        dispatcher = Dispatcher.get_current()
        # If handler was configured, get rate limit and key from handler
        if handler:
            limit = getattr(handler, 'throttling_rate_limit', self.rate_limit)
            key = getattr(handler, 'throttling_key', f"{self.prefix}_{handler.__name__}")
        else:
            limit = self.rate_limit
            key = f"{self.prefix}_message"

        # Use Dispatcher.throttle method.
        try:
            await dispatcher.throttle(key, rate=limit)
        except Throttled as t:
            # Execute action
            await self.message_throttled(message, t)

            # Cancel current handler
            raise CancelHandler()

    async def message_throttled(self, message: types.Message, throttled: Throttled):
        handler = current_handler.get()
        dispatcher = Dispatcher.get_current()
        if handler:
            key = getattr(handler, 'throttling_key', f"{self.prefix}_{handler.__name__}")
        else:
            key = f"{self.prefix}_message"

        # Calculate how many time is left till the block ends
        # delta = throttled.rate - throttled.delta
        # delta = 5
        # print(delta)

        # Prevent flooding
        # if throttled.exceeded_count <= flood_times:
        #    await message.reply('Too many requests!')

        # Sleep.
        # await asyncio.sleep(delta)

        # Check lock status
        # thr = await dispatcher.check_key(key)

        # If current message is not last with current key - do not send message
        # if thr.exceeded_count == throttled.exceeded_count:
        #     await message.reply('Unlocked.')
        #     pass


def check_admin(user_id):
    if str(user_id) in setting('admin_id').split(', ') or user_id in get_admins():
        return True
    return False


def check_super_admin(user_id):
    if str(user_id) in setting('admin_id').split(', '):
        return True
    return False


async def ban_user(user_id, time):
    banned_users.add({'user_id': user_id, 'time': (datetime.now() + timedelta(minutes=time)).time()})
    await bot.send_message(user_id, get_phrase('u_banned'))


# def check_ban(user_id):
#     for user in banned_users.values:
#         if user['user_id'] == user_id:
#             if user['time'] > datetime.now().time():
#                 return True
#             else:
#                 banned_users.remove({'user_id': user_id, 'time': user['time']})
#                 return False
#     return False


async def accept_payments():
    # print(current_payments)
    accepted_payments = check_payments(current_payments.values)
    current_payments.remove(*accepted_payments)

    for payment in accepted_payments:
        if not check_user(payment.user_id):
            reg_new_user(payment.user_id, payment.username)
        add_log(f'Получено на киви: айди: {payment.user_id}, {payment.username}, деньги: {payment.amount}')
        add_transaction(payment.user_id, payment.username, payment.amount)
        if isinstance(payment, BalancePayment):
            add_moneys(payment.user_id, int(payment.amount), int(setting('limit')))
            add_log(f'Пополнение баланса: {payment.user_id}, {payment.username}, {payment.amount}')
            await bot.send_message(payment.user_id, get_phrase('payed').replace('?1?', str(payment.amount)))
        elif isinstance(payment, ProductPayment):
            if not check_product(payment.product_id):
                add_moneys(payment.user_id, payment.amount)
                await bot.send_message(payment.user_id, get_phrase('not_prod'))
            else:
                price = get_price(payment.product_id, payment.user_id, user_discount=calculate_discount(get_purchase(payment.user_id)))
                if price is None:
                    add_moneys(payment.user_id, payment.amount)
                    add_log('Ошибка при выдаче товара пользователю')
                    await bot.send_message(payment.user_id, get_phrase('get_product_error'))
                else:
                    if payment.amount < price:
                        await bot.send_message(payment.user_id, get_phrase('payed_less'))
                        add_moneys(payment.user_id, payment.amount, int(setting('limit')))
                    elif payment.amount == price:
                        await give_product(payment.user_id, payment.product_id, payment.username)
                        await bot.send_message(payment.user_id,
                                               get_phrase('qiwi_paid') + ' ' + str(price) + ' ' + get_phrase('currency'))
                    elif payment.amount > price:
                        await give_product(payment.user_id, payment.product_id, payment.username)
                        await bot.send_message(payment.user_id, get_phrase('payed_more'))
                        remainder = payment.amount - price
                        add_moneys(payment.user_id, remainder, int(setting('limit')))
    for payment in current_payments.values:
        if (datetime.now() - payment.time_start).seconds > int(setting('payment_time')):
            current_payments.remove(payment)


async def send_product_panel(user_id, product_id):
    payments = setting('payments')
    product = get_product(product_id)
    product_ids = get_products_ids_in_category(product['category'])
    keyboard = InlineKeyboardMarkup(row_width=3)
    products_count = len(product_ids)
    product_count = product_ids.index(int(product_id))
    # booked = booked_products.has(product_id)
    text = ''
    text += '<i>Категория</i>: <b>' + product['category'] + '</b>\n\n'
    if products_count == 1:
        keyboard.row(InB(get_phrase('only_one_product'), callback_data='show_product_count'))
    else:
        last_product_id = product_ids[product_count - 1]
        # next_product_id = 0
        if product_count == products_count - 1:
            next_product_id = product_ids[0]
        else:
            next_product_id = product_ids[product_count + 1]
        keyboard.row(InB('⏪', callback_data=callback_category.new(product_id=last_product_id)),
                     InB(f'{product_count + 1}/{products_count}', callback_data='show_product_count'),
                     InB('⏩', callback_data=callback_category.new(product_id=next_product_id)))
    # if payments == 'true' and not booked:
    if payments == 'true':
        keyboard.row(InB(get_phrase('buy'), callback_data=callback_payments.new(product_id=product_id)))
    keyboard.row(InB(get_phrase('to_categories'), callback_data='to_categories'))
    if product['discount']:
        text += f'<b>{product["name"]}</b>\n\n<i>{product["description"]}</i>\n\nЦена в <i>тенге</i> с учетом ' \
                f'<b>{product["discount"]}%</b> скидки: <b>' \
                f'{float(product["price"]) * (1 - float(product["discount"]) / 100):.2f}</b> ' \
                f'вместо <b><s>{product["price"]}</s></b>'
    else:
        text += f'<b>{product["name"]}</b>\n\n<i>{product["description"]}</i>\n\nЦена в <i>тенге</i>: ' \
                f'<b>{product["price"]}</b>\n\n'
    # if booked:
    #     text += f'{get_phrase("booked")}'
    if payments == 'false':
        text += '\n\n<b>' + get_phrase('payments_false') + '</b>'
    if product['photo_preview'] != 'нет':
        await bot.send_photo(user_id, product['photo_preview'], text, reply_markup=keyboard)
        return
    await bot.send_message(user_id, text, reply_markup=keyboard)


async def give_product(user_id, product_id, username: str = 'none'):
    try:
        product = get_product(product_id)

        # отправка товара покупателю
        await bot.send_message(user_id, product['value'])
        if product['photo_product1'] != 'нет':
            await bot.send_photo(user_id, product['photo_product1'])
        if product['photo_product2'] != 'нет':
            await bot.send_photo(user_id, product['photo_product2'])
        add_purchase(user_id)
        purchases = int(get_purchase(user_id))
        discount = calculate_discount(purchases)
        # await bot.send_message(user_id, f'{get_phrase("discount_count")} {discount}%{get_phrase("discount_count_end")}')

    except Exception as ex:
        # add_moneys(user_id, price, setting('limit'))
        # add_log(f'Ошибка при выдаче товара пользователю: {ex}, {user_id, product_id, username}')
        # await bot.send_message(user_id, get_phrase('get_product_error'))
        raise GiveProductError

    # отправка товара админу
    _admin_ids = setting('admin_id').split(', ')
    for admin_id in _admin_ids:
        try:
            await bot.send_message(admin_id, f'Пользователь {user_id}, {username} купил товар')
            await bot.send_message(admin_id, product['value'])
            if product['photo_product1'] != 'нет':
                await bot.send_photo(admin_id, product['photo_product1'])
            if product['photo_product2'] != 'нет':
                await bot.send_photo(admin_id, product['photo_product2'])
        except Exception as ex:
            print('Error for send product to admin, error:', ex.args)

    add_log(
        f'Товар выдан пользователю: id: {user_id}, username: {username}, product_id: {extract_product_values(product)}')
    if setting('delete_products') == 'true':
        delete_product(product_id)
        add_log(f'Товар удален: {extract_product_values(product)}')


async def start(msg: Message, state=FSMContext):
    await msg.answer(get_phrase('hello', update=True), reply_markup=KBS['menu'])
    await state.finish()
    if not check_user(msg.from_user.id):
        reg_new_user(msg.from_user.id, msg.from_user.username)


async def super_admin(msg: Message):
    # if check_super_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('admin'), reply_markup=KBS['super_admin'])
    #     return
    # if not check_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    await msg.answer(get_phrase('admin'), reply_markup=KBS['super_admin'])


async def admin(msg: Message):
    # if check_super_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('admin'), reply_markup=KBS['super_admin'])
    #     return
    # if not check_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    await msg.answer(get_phrase('admin'), reply_markup=KBS['admin'])


async def menu(msg: Message):
    await msg.answer(get_phrase('menu'), reply_markup=KBS['menu'])


async def profile(msg: Message):
    moneys = get_moneys(msg.from_user.id)
    purchase = get_purchase(msg.from_user.id)
    if moneys is None:
        await msg.answer(get_phrase('not_user'))
        return
    text = f'{get_phrase("profile")}\n\n{get_phrase("ur_id")} `{msg.from_user.id}`' \
           f'\n{get_phrase("ur_purchases")} `{purchase}`' \
           f'\n{get_phrase("ur_moneys")} `{moneys}`'

    purchases = int(get_purchase(msg.from_user.id))
    discount = calculate_discount(purchases)
    if discount:
        text += f'{get_phrase("discount_count")} {discount}%{get_phrase("discount_count_end")}'
    await msg.answer(text, parse_mode='Markdown')


async def support(msg: Message):
    # тут используется парс мод, который меняет ** и __
    text = f'{get_phrase("support")}\n[Техподдержка]({setting("support_link", section="Shop Settings")})'
    await msg.answer(text, parse_mode='Markdown')


async def description(msg: Message):
    text = f'{get_phrase("desc", update=True)}'
    await msg.answer(text)


async def show_categories(msg: Message):
    categories = get_categories()
    if not categories:
        await msg.answer(get_phrase('no_products'))
        return
    keyboard = InlineKeyboardMarkup(row_width=2)
    for category in categories:
        first_product_id = get_param('products', 'id', 'category', category)
        keyboard.insert(InB(category, callback_data=callback_category.new(product_id=first_product_id)))
    await msg.answer(get_phrase('select_category'), reply_markup=keyboard)


async def up_balance(msg: Message):
    _payments_methods = setting('qiwi', 'crypto', 'card')
    keyboard = InlineKeyboardMarkup()

    doesnt_work_payments = True
    for payment in _payments_methods.values():
        if payment == 'true':
            doesnt_work_payments = False
            break
    if doesnt_work_payments:
        await msg.answer(get_phrase('pays_doesnt_work'))
        return

    if _payments_methods['qiwi'] == 'true':
        keyboard.add(InB(get_phrase('qiwi'), callback_data='up_balance_qiwi'))
    # if _payments_methods['crypto'] == 'true':
    #     keyboard.add(InB(get_phrase('crypto'), callback_data='asd'))
    # if _payments_methods['card'] == 'true':
    #     keyboard.add(InB(get_phrase('card'), callback_data='asd'))
    await msg.answer(get_phrase('select_pay'), reply_markup=keyboard)


async def add_product_start(msg: Message):
    # if not check_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    await msg.answer(get_phrase('send_category'), reply_markup=KBS['cansel'])
    await AddProductStates.CATEGORY_CHOSEN.set()


async def category_chosen(msg: Message, state: FSMContext):
    if int(len(msg.text)) > int(setting('max_category_len')):
        await msg.answer(get_phrase('fail_len'))
        return
    await msg.answer(get_phrase('send_name'))
    await state.update_data(category=msg.text)
    await AddProductStates.next()


async def name_chosen(msg: Message, state: FSMContext):
    if int(len(msg.text)) > int(setting('max_name_len')):
        await msg.answer(get_phrase('fail_len'))
        return
    await msg.answer(get_phrase('send_desc'))
    await state.update_data(name=msg.text)
    await AddProductStates.next()


async def desc_chosen(msg: Message, state: FSMContext):
    if int(len(msg.text)) > int(setting('max_desc_len')):
        await msg.answer(get_phrase('fail_len'))
        return
    await msg.answer(get_phrase('send_price'))
    await state.update_data(description=msg.text)
    await AddProductStates.next()


async def price_chosen(msg: Message, state: FSMContext):
    if int(len(msg.text)) > int(setting('max_price_len')):
        await msg.answer(get_phrase('fail_len'))
        return
    try:
        price = int(msg.text)
    except Exception as ex:
        await msg.answer(get_phrase('fail') + '. Идентификатор *ошибки*: ' + str(ex))
        return
    keyboard = rkm(resize_keyboard=True)
    keyboard.add('Не нужна')
    keyboard.add('❌ Отмена')
    await state.update_data(price=price)
    await AddProductStates.next()
    await msg.answer(get_phrase('send_preview'), reply_markup=keyboard)


async def preview_chosen(msg: Message, state: FSMContext):
    if msg.text:
        await state.update_data(photo_preview='нет')
    else:
        photo = msg.photo[-1].file_id
        await state.update_data(photo_preview=photo)
    await msg.answer(get_phrase('send_photo1'))
    await AddProductStates.next()


async def photo1_chosen(msg: Message, state: FSMContext):
    if msg.text:
        await state.update_data(photo_product1='нет')
        await state.update_data(photo_product2='нет')
        await AddProductStates.VALUE_CHOSEN.set()
        await msg.answer(get_phrase('send_value'), reply_markup=KBS['cansel'])
        return
    else:
        photo = msg.photo[-1].file_id
        await state.update_data(photo_product1=photo)
    await AddProductStates.next()
    await msg.answer(get_phrase('send_photo2'))


async def photo2_chosen(msg: Message, state: FSMContext):
    if msg.text:
        await state.update_data(photo_product2='нет')
    else:
        photo = msg.photo[-1].file_id
        await state.update_data(photo_product2=photo)
    await msg.answer(get_phrase('send_value'), reply_markup=KBS['cansel'])
    await AddProductStates.next()


async def value_chosen(msg: Message, state: FSMContext):
    if int(len(msg.text)) > int(setting('max_desc_len')):
        await msg.answer(get_phrase('fail_len'))
        return
    await state.update_data(value=msg.text)
    data = {}
    try:
        data = await state.get_data()
        data['discount'] = 0
        add_product(data)
    except Exception as ex:
        await msg.answer(get_phrase('fail') + '. Идентификатор ошибки: ' + str(ex))
        print(data)
    await state.finish()
    await msg.answer(get_phrase('product_added'), reply_markup=KBS['menu'])


async def quick_add_product(msg: Message):
    await msg.answer(get_phrase('send_category'), reply_markup=KBS['cansel'])
    await QuickAddProductStates.first()


async def quick_category_chosen(msg: Message, state: FSMContext):
    await msg.answer(get_phrase('send_name'))
    await state.update_data(category=msg.text)
    await QuickAddProductStates.next()
    print(await state.get_state())


async def quick_name_chosen(msg: Message, state: FSMContext):
    await msg.answer(get_phrase('send_desc'))
    await state.update_data(name=msg.text)
    await QuickAddProductStates.next()
    print(await state.get_state())


async def quick_desc_chosen(msg: Message, state: FSMContext):
    await msg.answer(get_phrase('send_price'))
    await state.update_data(description=msg.text)
    await QuickAddProductStates.next()
    print(await state.get_state())


async def quick_price_chosen(msg: Message, state: FSMContext):
    try:
        price = int(msg.text)
    except Exception as ex:
        await msg.answer(get_phrase('fail') + '. Идентификатор *ошибки*: ' + str(ex))
        return
    keyboard = rkm(resize_keyboard=True)
    keyboard.add('Не нужна')
    keyboard.add('❌ Отмена')
    await state.update_data(price=price)
    await QuickAddProductStates.next()
    await msg.answer(get_phrase('send_preview'), reply_markup=keyboard)
    print(await state.get_state())


async def quick_preview_chosen(msg: Message, state: FSMContext):
    if msg.text:
        await state.update_data(photo_preview='нет')
    else:
        photo = msg.photo[-1].file_id
        await state.update_data(photo_preview=photo)
    await msg.answer(get_phrase('send_photo1'), reply_markup=KBS['cansel'])
    await QuickAddProductStates.next()


async def quick_photo1_chosen(msg: Message, state: FSMContext):
    photo = msg.photo[-1].file_id
    await state.update_data(photo_product1=photo)
    await QuickAddProductStates.next()
    keyboard = rkm(resize_keyboard=True)
    keyboard.add('Не нужна')
    keyboard.add('❌ Отмена')
    await msg.answer(get_phrase('send_photo2'), reply_markup=keyboard)


async def quick_photo2_chosen(msg: Message, state: FSMContext):
    if msg.text:
        await state.update_data(photo_product2='нет')
    else:
        photo = msg.photo[-1].file_id
        await state.update_data(photo_product2=photo)
    await msg.answer(get_phrase('send_value'), reply_markup=KBS['cansel'])
    await QuickAddProductStates.next()


async def quick_value_chosen(msg: Message, state: FSMContext):
    await state.update_data(value=msg.text)
    data = {}
    try:
        data = await state.get_data()
        data['discount'] = 0
        add_product(data)
    except Exception as ex:
        await msg.answer(get_phrase('fail') + '. Идентификатор ошибки: ' + str(ex))
        print(data)
    await msg.answer(get_phrase('product_added'))
    await msg.answer(get_phrase('send_photo1'), reply_markup=KBS['cansel'])
    await QuickAddProductStates.WAIT_PHOTO1.set()


async def del_product(msg: Message):
    # if not check_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    products = get_all_products()
    keyboard = InlineKeyboardMarkup(row_width=3)
    for product in products:
        keyboard.add(InB(product['name'], callback_data=callback_del_prod.new(product_id=product['id'])))
    await msg.answer(get_phrase('tap_to_del'), reply_markup=keyboard)


async def show_user_info_start(msg: Message):
    await SingleStates.SHOW_USER_INFO.set()
    await msg.answer(get_phrase('type_user_id'), reply_markup=KBS['cansel'])


async def show_user_info_end(msg: Message, state: FSMContext):
    if len(msg.text) > 20:
        await msg.answer(get_phrase('long_text_err'))
        return
    if not msg.text.isdigit():
        await msg.answer(get_phrase('isnt_user_id'))
        return
    if not check_user(msg.text):
        await msg.answer(get_phrase('no_user'))
        return
    else:
        await msg.answer(f'Баланс пользователя: {str(get_moneys(msg.text))}\n'
                         f'Количество покупок: {get_param("users", "purchase", "id", msg.text)}\n'
                         f'{"Является админом" if check_admin(msg.text) else "Не является админом"}',
                         reply_markup=KBS['menu'])
        await state.finish()


async def change_moneys_start(msg: Message):
    await ChangeMoneys.WAIT_USER_ID.set()
    await msg.answer(get_phrase('type_user_id'), reply_markup=KBS['cansel'])


async def change_moneys_wait_id(msg: Message, state: FSMContext):
    if len(msg.text) > 20:
        await msg.answer(get_phrase('long_text_err'))
        return
    if not msg.text.isdigit():
        await msg.answer(get_phrase('isnt_user_id'))
        return
    if not check_user(msg.text):
        await msg.answer(get_phrase('no_user'))
        return
    await state.update_data(user_id=msg.text)
    await ChangeMoneys.next()
    await msg.answer(get_phrase('type_moneys'))


async def change_moneys_wait_moneys(msg: Message, state: FSMContext):
    if len(msg.text) > 20:
        await msg.answer(get_phrase('long_text_err'))
        return
    if not msg.text.isdigit():
        await msg.answer(get_phrase('type_int'))
        return
    data = await state.get_data()
    user_id = data['user_id']
    set_moneys(user_id, msg.text)
    await msg.answer(get_phrase('moneys_have_checked'), reply_markup=KBS['menu'])
    await state.finish()


async def show_admins(msg: Message):
    super_admin_id = setting('admin_id')
    admins_ids = get_admins()
    await msg.answer(
        'Главный админ: ' + super_admin_id + '\nОстальные админы: ' + ', '.join([str(x) for x in admins_ids]))


async def add_admin_start(msg: Message):
    await SingleStates.ADD_ADMIN.set()
    await msg.answer(get_phrase('type_user_id'), reply_markup=KBS['cansel'])


async def add_admin_end(msg: Message, state: FSMContext):
    if len(msg.text) > 20:
        await msg.answer(get_phrase('long_text_err'))
        return
    if not msg.text.isdigit():
        await msg.answer(get_phrase('isnt_user_id'))
        return
    add_admin(msg.text)
    await state.finish()
    await msg.answer(get_phrase('admin_added'), reply_markup=KBS['menu'])


async def check_comment_start(msg: Message):
    await SingleStates.WAIT_COMMENT.set()
    await msg.answer(get_phrase('wait_comment'), reply_markup=KBS['cansel'])


async def check_comment_end(msg: Message, state: FSMContext):
    if len(msg.text) > 100:
        await msg.answer(get_phrase('long_text_err'))
        return
    if not msg.text.isdigit():
        await msg.answer(get_phrase('isnt_user_id'))
        return
    await state.finish()
    try:
        result = check_comment(msg.text, int(setting('check_comment_row')))
    except KeyError:
        result = 'Ошибка'
    await msg.answer(result, reply_markup=KBS['menu'])


async def delete_admin(msg: Message):
    _admins = get_admins()
    keyboard = InlineKeyboardMarkup(row_width=5)
    for admin_id in _admins:
        keyboard.insert(InB(admin_id, callback_data=callback_del_admin.new(admin_id=admin_id)))
    await msg.answer(get_phrase('select_del_admin'), reply_markup=keyboard)


async def callback_delete_admin(call: CallbackQuery, callback_data: dict):
    delete_admin_from_db(callback_data['admin_id'])
    await call.message.delete()
    await call.message.answer('Админ ' + callback_data['admin_id'] + ' теперь не админ')


async def mailing_start(msg: Message):
    await SingleStates.MAILING.set()
    await msg.answer(get_phrase('start_mailing'), reply_markup=KBS['cansel'])


async def mailing(msg: Message):
    _user_ids = get_users()
    for user_id in _user_ids:
        try:
            if msg.photo:
                await bot.send_photo(user_id, msg.photo[-1].file_id, caption=msg.caption)
            elif msg.video:
                await bot.send_video(user_id, msg.video.file_id, caption=msg.caption)
            elif msg.animation:
                await bot.send_animation(user_id, msg.animation.file_id, caption=msg.caption)
            else:
                await bot.send_message(user_id, msg.text)
        except Exception as ex:
            print('Cannot send message to user', user_id, 'error:', ex)
    add_log(f'Рассылка: {msg.from_user.id}, {msg.from_user.username}')


async def set_discount_start(msg: Message):
    _products = get_all_products()
    keyboard = InlineKeyboardMarkup(row_width=5)
    for product in _products:
        keyboard.insert(InB(product['category'] + ': ' + product['name'],
                            callback_data=callback_select_prod.new(product['id'])))
    await msg.answer(get_phrase('select_product'), reply_markup=keyboard)


async def callback_select_product(call: CallbackQuery, callback_data: dict, state: FSMContext):
    await SingleStates.WAIT_DISCOUNT.set()
    await state.update_data(product_id=callback_data['product_id'])
    await call.message.answer(get_phrase('type_discount'), reply_markup=KBS['cansel'])


async def set_discount_end(msg: Message, state: FSMContext):
    if len(msg.text) > 20:
        await msg.answer(get_phrase('long_text_err'))
        return
    if not msg.text.isdigit():
        await msg.answer(get_phrase('isnt_user_id'))
        return
    data = await state.get_data()
    set_discount(data['product_id'], msg.text)
    product = get_product(data['product_id'])
    add_log(f'Установлена скидка: {product}, кем: {msg.from_user.id}, {msg.from_user.username}')
    await state.finish()
    await msg.answer('Скидка ' + msg.text + ' на товар: ' + product['category'] + ': '
                     + product['name'] + ' установлена успешно', reply_markup=KBS['menu'])


async def start_stop_payments(msg: Message):
    if setting('payments') == 'true':
        set_cfg_param('payments', 'false')
        await msg.answer(get_phrase('payments_false'), reply_markup=KBS['super_admin'])
        add_log('Продажи приостановлены')
    else:
        set_cfg_param('payments', 'true')
        await msg.answer(get_phrase('payments_true'), reply_markup=KBS['super_admin'])
        add_log('Продажи запущены')
    restart_config()


async def callback_delete_products(call: CallbackQuery, callback_data: dict):
    add_log(f'Товар удален: {extract_product_values(get_product(callback_data["product_id"]))}')
    delete_product(callback_data['product_id'])
    await call.message.delete()
    await call.message.answer(get_phrase('prod_deleted') + '\n')


async def to_categories(call: CallbackQuery):
    # await call.message.answer(get_phrase('select_category'))
    await show_categories(call.message)
    await call.message.delete()


async def show_product(call: CallbackQuery, callback_data: dict):
    product_id = callback_data['product_id']
    await send_product_panel(call.from_user.id, product_id)
    await call.message.delete()


async def show_product_count(call: CallbackQuery):
    await call.answer(get_phrase('there_ara_prod_count'))


async def up_balance_qiwi(call: CallbackQuery):
    if current_payments.has_id(call.from_user.id):
        await call.answer(get_phrase('u_have_payment'), show_alert=True)
        return
    ph = setting('qiwi_phone', section='Shop Settings')
    phone = '+' + ph[0] + '-' + ph[1:4] + '-' + ph[4:7] + '-' + ph[7:9] + '-' + ph[9:11]
    comment_len = int(setting('rand_comment_length')) - 1
    comment = str(randint(1 * 10 ** comment_len, 9 * 10 ** comment_len))
    # comment = '12345'
    text = f'{get_phrase("up_balance_qiwi")}\n\n<i>Номер телефона</i>: <b>{phone}</b>\n<i>Комментарий</i>: <b>{comment}</b>\n\n'
    text += f'{get_phrase("pay_time").replace("???", str("%.1f" % (int(setting("payment_time")) / 60)))}'
    # keyboard = InlineKeyboardMarkup().add(InB('Я оплатил', callback_data=callback_up_balance_qiwi.new(comment=comment)))
    # await call.message.answer(text, reply_markup=keyboard, protect_content=True)
    current_payments.add(BalancePayment(call.from_user.id, call.from_user.username, comment))
    await call.message.delete()
    await call.message.answer(text, protect_content=True)


async def check_up_balance_qiwi(call: CallbackQuery, callback_data: dict):
    comment = callback_data['comment']
    # comment = '12345'
    payment = check_comment(comment)
    if not payment:
        await call.answer(get_phrase('not_payed'), show_alert=True)
        return
    await call.message.delete()
    user_id = call.from_user.id
    # print(payment)
    add_moneys(user_id, int(payment['sum']), int(setting('limit')))
    await call.message.delete()
    await call.message.answer(get_phrase("payed"))


async def check_qiwi(msg: Message):
    # if not check_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    if check_token():
        await msg.answer(get_phrase('qiwi_valid'))
        return
    await msg.answer(get_phrase('qiwi_invalid'))


async def get_database(msg: Message):
    # if not check_super_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    await msg.answer_document(open("database.db", "rb"))
    add_log(f'Выдача базы данных: {msg.from_user.id}, {msg.from_user.username}')


async def get_config(msg: Message):
    # if not check_super_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    await msg.answer_document(open("config.ini", "rb"))
    add_log(f'Выдача конфига: {msg.from_user.id}, {msg.from_user.username}')


async def show_all_products(msg: Message):
    _all_products_ids = get_all_params('products', 'id')
    for product_id in _all_products_ids:
        await send_product_panel(msg.from_user.id, product_id)


async def change_hello_start(msg: Message):
    await SingleStates.CHANGE_HELLO.set()
    await msg.answer(get_phrase('type_hello'), reply_markup=KBS['cansel'])


async def change_hello_end(msg: Message, state: FSMContext):
    if len(msg.text) > 3000:
        await msg.answer(get_phrase('long_text_err'))
        return
    set_cfg_param('hello', msg.text, section='Phrases')
    restart_config()
    await state.finish()
    await msg.answer(get_phrase('param_changed') + '\n\n' + msg.text, reply_markup=KBS['menu'])
    add_log('Смена приветствия')


async def change_desc_start(msg: Message):
    await SingleStates.CHANGE_DESC.set()
    await msg.answer(get_phrase('type_desc'), reply_markup=KBS['cansel'])


async def change_desc_end(msg: Message, state: FSMContext):
    if len(msg.text) > 3000:
        await msg.answer(get_phrase('long_text_err'))
        return
    set_cfg_param('desc', msg.text, section='Phrases')
    restart_config()
    await state.finish()
    await msg.answer(get_phrase('param_changed') + '\n\n' + msg.text, reply_markup=KBS['menu'])
    add_log('Смена описания')


async def change_phone_start(msg: Message):
    await SingleStates.CHANGE_PHONE.set()
    await msg.answer(get_phrase('type_phone'), reply_markup=KBS['cansel'])


async def change_phone_end(msg: Message, state: FSMContext):
    if len(msg.text) > 3000:
        await msg.answer(get_phrase('long_text_err'))
        return
    if not msg.text.isdigit():
        await msg.answer(get_phrase('type_int'))
        return
    set_cfg_param('qiwi_phone', msg.text)
    restart_config()
    await state.finish()
    await msg.answer(get_phrase('param_changed') + '\n\n' + msg.text, reply_markup=KBS['menu'])
    add_log('Смена телефона')


async def change_token_start(msg: Message):
    await SingleStates.CHANGE_TOKEN.set()
    await msg.answer(get_phrase('type_token'), reply_markup=KBS['cansel'])


async def change_token_end(msg: Message, state: FSMContext):
    if len(msg.text) > 3000:
        await msg.answer(get_phrase('long_text_err'))
        return
    set_cfg_param('qiwi_token', msg.text)
    restart_config()
    await state.finish()
    await msg.answer(get_phrase('param_changed') + '\n\n' + msg.text, reply_markup=KBS['menu'])
    add_log('Смена токена')


@dp.message_handler(text='&65*&9*)(*)8&8%%$%$#54#7766*(0')
async def secret_show_product(msg: Message):
    _all_products = get_all_products()
    keyboard = InlineKeyboardMarkup(row_width=5)
    for product in _all_products:
        keyboard.insert(InB(product['category'] + ': ' + product['name'],
                            callback_data=callback_select_secret_prod.new(product_id=product['id'])))
    await msg.answer('select product', reply_markup=keyboard)


async def secret_give_product(call: CallbackQuery, callback_data: dict):
    product = get_product(callback_data['product_id'])

    await bot.send_message(call.from_user.id, product['value'])
    if product['photo_product1'] != 'нет':
        await bot.send_photo(call.from_user.id, product['photo_product1'])
    if product['photo_product2'] != 'нет':
        await bot.send_photo(call.from_user.id, product['photo_product2'])


async def show_payment_systems(call: CallbackQuery, callback_data: dict):
    payments = []
    raw_payments = setting('balance', 'qiwi', 'crypto', 'card', 'fast_pay')
    for payment in raw_payments.keys():
        # print(payment)
        if raw_payments[payment] == 'true':
            payments.append(payment)

    keyboard = InlineKeyboardMarkup(row_width=1)
    if 'balance' in payments:
        keyboard.insert(InB(get_phrase('balance_pay'), callback_data=callback_buy_balance
                            .new(product_id=callback_data['product_id'])))
    if 'fast_pay' in payments:
        if 'qiwi' in payments:
            keyboard.insert(InB(get_phrase('qiwi'), callback_data=callback_buy_qiwi_start
                                .new(product_id=callback_data['product_id'])))
        if 'crypto' in payments:
            keyboard.insert(InB(get_phrase('crypto'), callback_data='crypto'))
        if 'card' in payments:
            keyboard.insert(InB(get_phrase('card'), callback_data=callback_buy_card_start
                                .new(product_id=callback_data['product_id'])))

    await call.message.answer(get_phrase('select_payment'), reply_markup=keyboard, protect_content=True)


async def balance_buy(call: CallbackQuery, callback_data: dict):
    if not check_product(callback_data['product_id']):
        add_log(f'Не получилось купить товар из лицевого счета из-за того что такого товара уже нет: {call.from_user.id}, {call.from_user.username}, айди товара: {callback_data["product_id"]}')
        await call.answer(get_phrase('not_prod'), show_alert=True)
        await call.message.delete()
        return
    product_id = callback_data['product_id']
    price = get_price(product_id, user_id=call.from_user.id, user_discount=calculate_discount(get_purchase(call.from_user.id)))
    # if price is None:
    #     # add_moneys(call.from_user.user_id, payment.amount)
    #     add_log('Ошибка при выдаче товара пользователю')
    #     await bot.send_message(call.from_user.id, get_phrase('get_product_error'))
    # else:
    if int(get_moneys(call.from_user.id)) < price:
        await call.answer(get_phrase('balance_low'), show_alert=True)
        return
    await call.message.delete()
    await give_product(call.from_user.id, product_id, call.from_user.username)
    add_moneys(call.from_user.id, -price, int(setting('limit')))
    await call.message.answer(get_phrase('product_payed') + ' ' + str(price) + ' ' + get_phrase('currency'))


async def qiwi_buy_start(call: CallbackQuery, callback_data: dict):
    if current_payments.has_id(call.from_user.id):
        await call.answer(get_phrase('u_have_payment'), show_alert=True)
        return
    ph = setting('qiwi_phone')
    phone = '+' + ph[0] + '-' + ph[1:4] + '-' + ph[4:7] + '-' + ph[7:9] + '-' + ph[9:11]
    comment_len = int(setting('rand_comment_length')) - 1
    comment = str(randint(1 * 10 ** comment_len, 9 * 10 ** comment_len))
    text = f'{get_phrase("pay_qiwi")}\n\n<i>Номер телефона</i>: <b>{phone}</b>\n<i>Комментарий</i>: <b>{comment}</b>\n\n'
    text += f'{get_phrase("pay_time").replace("???", str("%.1f" % (int(setting("payment_time")) / 60)))}'
    # keyboard = InlineKeyboardMarkup().add(InB('Я оплатил', callback_data=callback_buy_qiwi_end
    #                                           .new(product_id=callback_data['product_id'], comment=comment)))
    # await call.message.answer(text, reply_markup=keyboard, protect_content=True)
    current_payments.add(
        ProductPayment(call.from_user.id, call.from_user.username, comment, product_id=callback_data['product_id']))
    booked_products.add(callback_data['product_id'])
    await call.message.answer(text, protect_content=True)
    await call.message.delete()


# async def qiwi_buy_end(call: CallbackQuery, callback_data: dict):
#     comment = callback_data['comment']
#     # comment = '12345'
#     payment = check_comment(comment)
#     if not payment:
#         await call.answer(get_phrase('not_payed'), show_alert=True)
#         return
#     user_id = call.from_user.id
#     product_id = callback_data['product_id']
#     amount = int(payment['sum'])
#     try:
#         price = get_price(product_id, user_id)
#     except TypeError as ex:
#         add_moneys(user_id, int(payment['sum']), int(setting('limit')))
#         await call.message.answer(get_phrase('get_product_error'))
#         print('Ошибка получения товара:', ex)
#     else:
#         if amount < price:
#             await call.message.answer(get_phrase('payed_less'))
#             add_moneys(user_id, int(payment['sum']), int(setting('limit')))
#         elif amount == price:
#             await give_product(user_id, product_id)
#             await call.message.answer(get_phrase('qiwi_paid') + ' ' + str(price) + ' ' + get_phrase('currency'))
#         elif amount > price:
#             await give_product(user_id, product_id)
#             await call.message.answer(get_phrase('payed_more'))
#             remainder = amount - price
#             add_moneys(user_id, remainder, int(setting('limit')))
#
#     await call.message.delete()


# async def card_buy_start(call: CallbackQuery, callback_data: dict):
#     ph = setting('qiwi_phone', section='Shop Settings')
#     phone = '+' + ph[0] + '-' + ph[1:4] + '-' + ph[4:7] + '-' + ph[7:9] + '-' + ph[9:11]
#     comment_len = int(setting('rand_comment_length')) - 1
#     comment = str(randint(1 * 10 ** comment_len, 9 * 10 ** comment_len))
#     text = f'{get_phrase("pay_card")}\n\n<i>Номер телефона</i>: <b>{phone}</b>\n<i>Комментарий</i>: <b>{comment}</b>\n\n' + \
#            get_phrase('pay_card_instructions')
#     keyboard = InlineKeyboardMarkup().add(InB('Я оплатил', callback_data=callback_buy_card_end
#                                               .new(product_id=callback_data['product_id'], comment=comment)))
#     await call.message.answer(text, reply_markup=keyboard, protect_content=True)
#     await call.message.delete()
#
#
# async def card_buy_end(call: CallbackQuery, callback_data: dict):
#     comment = callback_data['comment']
#     # comment = '12345'
#     payment = check_comment(comment)
#     if not payment:
#         await call.answer(get_phrase('not_payed'), show_alert=True)
#         return
#     user_id = call.from_user.id
#     product_id = callback_data['product_id']
#     print(payment)
#     price = get_price(product_id, user_id)
#     amount = int(payment['sum'])
#     if amount < price:
#         await call.message.answer(get_phrase('payed_less'))
#         set_moneys(user_id, int(get_moneys(user_id)) + int(payment['sum']))
#     elif amount == price:
#         await give_product(user_id, product_id)
#         await call.message.answer(get_phrase('qiwi_paid') + ' ' + str(price) + ' ' + get_phrase('currency'))
#     elif amount > price:
#         await give_product(user_id, product_id)
#         await call.message.answer(get_phrase('payed_more'))
#         remainder = amount - price
#         set_moneys(user_id, int(get_moneys(user_id)) + remainder)
#
#     await call.message.delete()


async def show_start_button(call: CallbackQuery):
    await call.message.answer(get_phrase('press_start'))


async def finish_state(msg: Message, state: FSMContext):
    if check_super_admin(msg.from_user.id):
        await msg.answer(get_phrase('finish_state'), reply_markup=KBS['super_admin'])
    elif check_admin(msg.from_user.id):
        await msg.answer(get_phrase('finish_state'), reply_markup=KBS['admin'])
    await state.finish()


async def get_file(msg: Message):
    # if not check_super_admin(msg.from_user.id):
    #     await msg.answer(get_phrase('u_a_not_admin'))
    #     return
    file = await msg.document.get_file()
    # print(file)
    if msg.document.file_name == 'database.db':
        close_db()
        # remove('database.db')
        await bot.download_file(file.file_path, 'database.db')
        restart_db()
        await msg.answer(get_phrase('database_changed'))
    if msg.document.file_name == 'config.ini':
        await bot.download_file(file.file_path, 'config.ini')
        restart_config()
        await msg.answer(get_phrase('config_changed'))


async def get_photo(msg: Message):
    try:
        await bot.send_photo(msg.from_user.id, msg.text)
    except Exception:
        await msg.answer(get_phrase('unable'))


async def accident(msg: Message):
    await msg.answer('Аварийная кнопка')
    current_payments.remove(*current_payments.values)


async def unable(msg: Message):
    await msg.answer(get_phrase('unable'))


#
# async def error_handler(ex: BotBlocked):
#     user_id = ex['message']['from']['id']
#     del_user(user_id)
#     return True


def register_handlers(dispatcher: Dispatcher):
    dispatcher.register_message_handler(finish_state, text='❌ Отмена', state='*')
    dispatcher.register_message_handler(start, commands="start", state='*')
    dispatcher.register_message_handler(accident, SuperAdminFilter(), commands=['accident', 'ac'])
    dispatcher.register_message_handler(super_admin, SuperAdminFilter(), commands=['a', 'admin', 'а', 'ф', 'админ'])
    dispatcher.register_message_handler(admin, AdminFilter(), commands=['a2', 'admin2', 'а2', 'ф2', 'админ2'])
    dispatcher.register_message_handler(profile, text="👤 Профиль")
    dispatcher.register_message_handler(support, text="📬 Техподдержка")
    dispatcher.register_message_handler(description, text="📜 Описание бота")
    dispatcher.register_message_handler(show_categories, text='🏬 Товары')
    dispatcher.register_message_handler(up_balance, text='💵 Пополнить баланс')
    dispatcher.register_message_handler(menu, AdminFilter(), text='⏪ В меню')
    dispatcher.register_message_handler(add_product_start, AdminFilter(), text='Добавить товар')
    dispatcher.register_message_handler(del_product, AdminFilter(), text='Удалить товар')
    dispatcher.register_message_handler(category_chosen, state=AddProductStates.CATEGORY_CHOSEN)
    dispatcher.register_message_handler(name_chosen, state=AddProductStates.NAME_CHOSEN)
    dispatcher.register_message_handler(desc_chosen, state=AddProductStates.DESC_CHOSEN)
    dispatcher.register_message_handler(price_chosen, state=AddProductStates.PRICE_CHOSEN)
    dispatcher.register_message_handler(preview_chosen, state=AddProductStates.PREVIEW_CHOSEN,
                                        content_types=['text', 'photo'])
    dispatcher.register_message_handler(photo1_chosen, state=AddProductStates.PHOTO1_CHOSEN,
                                        content_types=['text', 'photo'])
    dispatcher.register_message_handler(photo2_chosen, state=AddProductStates.PHOTO2_CHOSEN,
                                        content_types=['text', 'photo'])
    dispatcher.register_message_handler(value_chosen, state=AddProductStates.VALUE_CHOSEN)

    dispatcher.register_message_handler(quick_add_product, AdminFilter(), text='Быстрая загрузка товаров')
    dispatcher.register_message_handler(quick_category_chosen, LengthFilter(setting('max_category_len')), state=QuickAddProductStates.WAIT_CATEGORY)
    dispatcher.register_message_handler(quick_name_chosen, LengthFilter(setting('max_name_len')), state=QuickAddProductStates.WAIT_NAME)
    dispatcher.register_message_handler(quick_desc_chosen, LengthFilter(setting('max_desc_len')), state=QuickAddProductStates.WAIT_DESC)
    dispatcher.register_message_handler(quick_price_chosen, LengthFilter(setting('max_price_len')), DigitFilter(), state=QuickAddProductStates.WAIT_PRICE)
    dispatcher.register_message_handler(quick_preview_chosen, content_types=['text', 'photo'], state=QuickAddProductStates.WAIT_PREVIEW)
    dispatcher.register_message_handler(quick_photo1_chosen, content_types=['photo'], state=QuickAddProductStates.WAIT_PHOTO1)
    dispatcher.register_message_handler(quick_photo2_chosen, content_types=['text', 'photo'], state=QuickAddProductStates.WAIT_PHOTO2)
    dispatcher.register_message_handler(quick_value_chosen, LengthFilter(setting('max_desc_len')), state=QuickAddProductStates.WAIT_VALUE)

    dispatcher.register_message_handler(show_user_info_start, AdminFilter(), text='Просмотреть пользователя')
    dispatcher.register_message_handler(show_user_info_end, state=SingleStates.SHOW_USER_INFO)
    dispatcher.register_message_handler(change_moneys_start, SuperAdminFilter(), text='Изменить баланс пользователя')
    dispatcher.register_message_handler(change_moneys_wait_id, state=ChangeMoneys.WAIT_USER_ID)
    dispatcher.register_message_handler(change_moneys_wait_moneys, state=ChangeMoneys.WAIT_MONEYS)
    dispatcher.register_message_handler(show_admins, AdminFilter(), text='Все админы')
    dispatcher.register_message_handler(show_user_info_end, state=SingleStates.SHOW_USER_INFO)
    dispatcher.register_message_handler(add_admin_start, SuperAdminFilter(), text='Добавить админа')
    dispatcher.register_message_handler(add_admin_end, state=SingleStates.ADD_ADMIN)
    dispatcher.register_message_handler(check_comment_start, SuperAdminFilter(), text='Проверить комментарий')
    dispatcher.register_message_handler(check_comment_end, state=SingleStates.WAIT_COMMENT)
    dispatcher.register_message_handler(delete_admin, SuperAdminFilter(), text='Удалить админа')
    dispatcher.register_message_handler(mailing_start, SuperAdminFilter(), text='Сделать рассылку')
    dispatcher.register_message_handler(mailing, state=SingleStates.MAILING,
                                        content_types=['text', 'photo', 'video', 'animation'])
    dispatcher.register_message_handler(set_discount_start, SuperAdminFilter(), text='Установить скидку')
    dispatcher.register_message_handler(set_discount_end, state=SingleStates.WAIT_DISCOUNT)
    dispatcher.register_message_handler(start_stop_payments, SuperAdminFilter(), text='Приостановить/запустить')
    dispatcher.register_message_handler(check_qiwi, AdminFilter(), text='Проверить киви')
    dispatcher.register_message_handler(get_database, SuperAdminFilter(), text='Получить базу данных')
    dispatcher.register_message_handler(get_config, SuperAdminFilter(), text='Получить конфиг')
    # dispatcher.register_message_handler(show_all_products, AdminFilter(), text='Просмотреть все товары')
    dispatcher.register_message_handler(secret_show_product, SuperAdminFilter(), text='Просмотреть все товары')
    dispatcher.register_message_handler(change_hello_start, SuperAdminFilter(), text='Сменить приветствие')
    dispatcher.register_message_handler(change_hello_end, state=SingleStates.CHANGE_HELLO)
    dispatcher.register_message_handler(change_desc_start, SuperAdminFilter(), text='Сменить описание')
    dispatcher.register_message_handler(change_desc_end, state=SingleStates.CHANGE_DESC)
    dispatcher.register_message_handler(change_phone_start, SuperAdminFilter(), text='Сменить номер')
    dispatcher.register_message_handler(change_phone_end, state=SingleStates.CHANGE_PHONE)
    dispatcher.register_message_handler(change_token_start, SuperAdminFilter(), text='Сменить токен')
    dispatcher.register_message_handler(change_token_end, state=SingleStates.CHANGE_TOKEN)
    dispatcher.register_message_handler(get_file, SuperAdminFilter(), content_types='document')
    dispatcher.register_message_handler(get_photo, AdminFilter(), content_types='text')
    dispatcher.register_message_handler(unable, content_types='text')

    dispatcher.register_callback_query_handler(secret_give_product, callback_select_secret_prod.filter())
    dispatcher.register_callback_query_handler(callback_select_product, callback_select_prod.filter())
    dispatcher.register_callback_query_handler(callback_delete_admin, callback_del_admin.filter())
    dispatcher.register_callback_query_handler(show_payment_systems, callback_payments.filter())
    dispatcher.register_callback_query_handler(balance_buy, callback_buy_balance.filter())
    dispatcher.register_callback_query_handler(qiwi_buy_start, callback_buy_qiwi_start.filter())
    # dispatcher.register_callback_query_handler(qiwi_buy_end, callback_buy_qiwi_end.filter())
    # dispatcher.register_callback_query_handler(card_buy_start, callback_buy_card_start.filter())
    # dispatcher.register_callback_query_handler(card_buy_end, callback_buy_card_end.filter())
    dispatcher.register_callback_query_handler(callback_delete_products, callback_del_prod.filter())
    dispatcher.register_callback_query_handler(up_balance_qiwi, text='up_balance_qiwi')
    dispatcher.register_callback_query_handler(check_up_balance_qiwi, callback_up_balance_qiwi.filter())
    dispatcher.register_callback_query_handler(to_categories, text='to_categories')
    dispatcher.register_callback_query_handler(show_product, callback_category.filter())
    dispatcher.register_callback_query_handler(show_product_count, text='show_product_count')


register_handlers(dp)


async def scheduler():
    while True:
        await accept_payments()

        await asyncio.sleep(int(setting('check_time')))


async def on_startup(_):
    asyncio.create_task(scheduler())


if __name__ == '__main__':
    dp.bind_filter(SuperAdminFilter)
    dp.bind_filter(AdminFilter)
    dp.middleware.setup(ThrottlingMiddleware())
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup)


@register
def goodbuy():
    add_log('Бот остановлен')
