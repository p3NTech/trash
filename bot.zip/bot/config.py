import configparser

from aiogram import types, Dispatcher
from aiogram.dispatcher.handler import current_handler, CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.types import ReplyKeyboardMarkup as rkm, Message
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.utils.callback_data import CallbackData
from aiogram.dispatcher.filters import Filter
from aiogram.utils.exceptions import Throttled

from database import get_admins


class SuperAdminFilter(Filter):
    key = 'super_admin_filter'

    async def check(self, msg: Message) -> bool:
        return str(msg.from_user.id) in get_params('admin_id').split(', ')


cfg = configparser.ConfigParser()
cfg.read('config.ini', encoding="utf-8")


def restart_config():
    cfg.read('config.ini', encoding="utf-8")


def get_params(*params, section: str = 'Shop Settings', update=False):
    if update:
        cfg.read('config.ini', encoding="utf-8")
    if len(params) == 1:
        return cfg[section][params[0]]
    else:
        parameters = {}
        for param in params:
            parameters[param] = cfg[section][param]
            # parameters.append({param: cfg[section][param]})
        return parameters


def set_cfg_param(param_name, value, section='Shop Settings'):
    cfg.set(section, param_name, value)
    with open('config.ini', "w", encoding="utf-8") as config_file:
        cfg.write(config_file)


def get_phrase(phrase, update=False):
    if update:
        cfg.read('config.ini', encoding="utf-8")
    return cfg['Phrases'][phrase]


callback_category = CallbackData('category', 'product_id')
callback_up_balance_qiwi = CallbackData('up_balance_qiwi', 'comment')
callback_payments = CallbackData('payments', 'product_id')
callback_del_prod = CallbackData('del_prod', 'product_id')
callback_qiwi = CallbackData('qiwi', 'comment')
callback_buy_balance = CallbackData('buy_balance', 'product_id')
callback_buy_qiwi_start = CallbackData('buy_qiwi_start', 'product_id')
callback_buy_qiwi_end = CallbackData('buy_qiwi_end', 'product_id', 'comment')
callback_buy_card_start = CallbackData('buy_card_start', 'product_id')
callback_buy_card_end = CallbackData('buy_card_end', 'product_id', 'comment')
callback_del_admin = CallbackData('del_admin', 'admin_id')
callback_select_prod = CallbackData('select_prod', 'product_id')
callback_select_secret_prod = CallbackData('select_secret_prod', 'product_id')


KEYBOARDS = {
    'none': rkm(),
    'menu': rkm(resize_keyboard=True).row('🏬 Товары', '👤 Профиль')
    .row('📬 Техподдержка', '💵 Пополнить баланс')
    .row('📜 Описание бота', '/start'),
    # 'menu': rkm(resize_keyboard=True).row('🏬 Товары', '👤 Профиль')
    # .row('📬 Техподдержка', '📜 Описание бота'),
    'cansel': rkm(resize_keyboard=True).row('❌ Отмена'),
    'not_need': rkm(resize_keyboard=True).row('Не нужна'),
    'super_admin': rkm(resize_keyboard=True).row('Добавить товар', 'Удалить товар', 'Быстрая загрузка товаров')
    .row('Изменить баланс пользователя', 'Просмотреть пользователя')
    .row('Все админы', 'Добавить админа', 'Проверить комментарий')
    .row('Удалить админа', 'Проверить киви', 'Сделать рассылку')
    .row('Установить скидку', 'Приостановить/запустить')
    .row('Получить базу данных', 'Получить конфиг', 'Просмотреть все товары')
    .row('Сменить приветствие', 'Сменить описание', 'Сменить номер', 'Сменить токен')
    .row('⏪ В меню'),
    'admin': rkm(resize_keyboard=True).row('Добавить товар', 'Удалить товар', 'Быстрая загрузка товаров')
    .row('Проверить киви', '⏪ В меню'),
}
