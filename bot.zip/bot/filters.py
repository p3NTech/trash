from aiogram.dispatcher.filters import BoundFilter
from aiogram.types import Message


from config import get_params as setting, get_phrase
from database import get_admins


class AdminFilter(BoundFilter):
    key = 'admin_filter'

    async def check(self, msg: Message) -> bool:
        if str(msg.from_user.id) in setting('admin_id').split(', ') or msg.from_user.id in get_admins():
            return True
        return False


class SuperAdminFilter(BoundFilter):
    key = 'super_admin_filter'

    async def check(self, msg: Message) -> bool:
        if str(msg.from_user.id) in setting('admin_id').split(', '):
            return True
        return False


class DigitFilter(BoundFilter):
    key = 'digit_filter'

    async def check(self, msg: Message):
        if not msg.text.isdigit():
            await msg.answer(get_phrase('digit_fail'))
            return False
        else:
            return True


class LengthFilter(BoundFilter):
    key = 'lenght_filter'

    def __init__(self, max_len):
        self.max_len = int(max_len)

    async def check(self, msg: Message):
        if len(msg.text) >= self.max_len:
            await msg.answer(get_phrase('fail_len'))
            return False
        else:
            return True
