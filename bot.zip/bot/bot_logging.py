import datetime
import os.path


logging_file_name = 'logs.txt'


if not os.path.exists(logging_file_name):
    with open(logging_file_name, 'w') as file:
        pass


def add_log(text):
    with open(logging_file_name, 'a', encoding='utf-8') as log_file:
        log = f'\n__________________________\n{datetime.datetime.now()}\n{text}'
        log_file.write(log)
