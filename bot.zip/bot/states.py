from aiogram.dispatcher.filters.state import StatesGroup, State


class AddProductStates(StatesGroup):
    CATEGORY_CHOSEN = State()
    NAME_CHOSEN = State()
    DESC_CHOSEN = State()
    PRICE_CHOSEN = State()
    PREVIEW_CHOSEN = State()
    PHOTO1_CHOSEN = State()
    PHOTO2_CHOSEN = State()
    VALUE_CHOSEN = State()


class QuickAddProductStates(StatesGroup):
    WAIT_CATEGORY = State()
    WAIT_NAME = State()
    WAIT_DESC = State()
    WAIT_PRICE = State()
    WAIT_PREVIEW = State()
    WAIT_PHOTO1 = State()
    WAIT_PHOTO2 = State()
    WAIT_VALUE = State()


class ChangeMoneys(StatesGroup):
    WAIT_USER_ID = State()
    WAIT_MONEYS = State()


class SingleStates(StatesGroup):
    SHOW_USER_INFO = State()
    ADD_ADMIN = State()
    MAILING = State()
    WAIT_DISCOUNT = State()
    CHANGE_HELLO = State()
    CHANGE_DESC = State()
    CHANGE_PHONE = State()
    CHANGE_TOKEN = State()
    WAIT_COMMENT = State()
