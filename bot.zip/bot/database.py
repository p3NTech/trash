import sqlite3
from types import FunctionType

import config
from bot_logging import add_log

connection = sqlite3.connect('database.db')
connection.row_factory = sqlite3.Row
cursor = connection.cursor()


class GetProductException(Exception):
    params = {}

    def __init__(self, **kwargs):
        self.params = kwargs

    def __str__(self):
        return f'Не получилось достать товар из базы данных {self.params}'


def restart_db():
    global connection, cursor
    connection = sqlite3.connect('database.db')
    connection.row_factory = sqlite3.Row
    cursor = connection.cursor()
    add_log('База данных перезагружена')


def close_db():
    connection.close()


def extract_values(values):
    return_values = []
    for value in values:
        return_values.append(value[0])
    return return_values


def extract_product_values(product):
    return dict(zip(product.keys(), product))


def get_param(table: str, need_param: str, key_param_name: str, key_value):
    cursor.execute(f'''
    SELECT {need_param}
    FROM {table}
    WHERE {key_param_name} = ?
    ''', (key_value,))
    return cursor.fetchone()[0]


def get_line(table: str, key_param: str, key_value):
    cursor.execute(f'''
    SELECT *
    FROM {table}
    WHERE {key_param} = ?
    ''', (key_value,))
    return cursor.fetchone()


def get_all_params(table: str, need_param: str):
    connection.row_factory = None
    cursor.execute(f'''
    SELECT {need_param}
    FROM {table}
    ''')
    return extract_values(cursor.fetchall())


def get_all_params_with_condition(table: str, need_param: str, key_param: str, key_value):
    cursor.execute(f'''
    SELECT {need_param}
    FROM {table}
    WHERE {key_param} = ?
    ''', (key_value,))
    return extract_values(cursor.fetchall())


def get_product(product_id):
    # connection.row_factory = sqlite3.Row
    # return None
    product = get_line('products', 'id', product_id)
    if product is None:
        raise GetProductException(value=None)
    return product


def check_product(product_id):
    cursor.execute(f'''
    SELECT id
    FROM products
    WHERE id = ?
    ''', (product_id,))
    if not cursor.fetchone() is None:
        return True
    return False


def get_product_param(product_id, param_name):
    cursor.execute(f'''
    SELECT {param_name}
    FROM products
    WHERE id = ?
    ''', (product_id,))
    try:
        return cursor.fetchone()[0]
    except Exception as ex:
        raise GetProductException(exception=ex)


def get_price(product_id, user_id, user_discount):
    # return None
    row_price = get_product_param(product_id, 'price')
    discount = get_product_param(product_id, 'discount')
    return float(row_price) * (1 - (float(discount) + float(user_discount)) / 100)


def get_categories():
    row_categories = get_all_params('products', 'category')
    categories = []
    for category in row_categories:
        if category not in categories:
            categories.append(category)
    return categories


def get_products_ids_in_category(category: str):
    return get_all_params_with_condition('products', 'id', 'category', category)


def set_param(table, param_name,  value, key_param_name, key_param_value):
    cursor.execute(f'''
    UPDATE {table}
    SET {param_name} = ?
    WHERE {key_param_name} = ?
    ''', (value, key_param_value,))
    connection.commit()


def reg_new_user(user_id: int, username: str):
    cursor.execute(f'''
    INSERT INTO users
    VALUES (?, ?, ?, ?)
    ''', (user_id, username, 0, 0))
    connection.commit()
    add_log(f'Зарегистрирован новый пользователь: id: {user_id}, username: {username}')


def del_user(user_id):
    cursor.execute(f'''
    DELETE FROM users
    WHERE user_id = ?
    ''', (user_id,))
    connection.commit()
    add_log(f'Пользователь удален: {user_id}')


def check_user(user_id):
    cursor.execute(f'''
    SELECT id
    FROM users
    WHERE id = ?
    ''', (user_id,))
    if cursor.fetchone():
        return True
    return False


def get_users():
    return get_all_params('users', 'id')


def get_moneys(user_id):
    cursor.execute('''
    SELECT moneys
    FROM users
    WHERE id = ?
    ''', (user_id,))
    try:
        moneys = cursor.fetchone()[0]
        # print(moneys)
        return round(moneys, 2)
    except Exception as ex:
        print('Get balance error. Error:', ex)
        return


def set_moneys(user_id, moneys):
    cursor.execute(f'''
    UPDATE users
    SET moneys = {moneys}
    WHERE id = ?
    ''', (user_id,))
    connection.commit()
    add_log(f'Установлен баланс: id: {user_id}, баланс: {moneys}')


def add_moneys(user_id, moneys, limit: int = 30000):
    if moneys > limit:
        moneys = limit
    cursor.execute(f'''
    UPDATE users
    SET moneys = moneys + {moneys}
    WHERE id = ?
    ''', (user_id,))
    connection.commit()
    if moneys >= 0:
        add_log(f'Баланс увеличен: {user_id}, {moneys}')
    else:
        add_log(f'Баланс уменьшен: {user_id}, {moneys}')


def add_product(product: dict):
    cursor.execute(f'''
    INSERT INTO products
    VALUES (?{", ?" * (len(product))})
    ''', (None, *product.values()))
    connection.commit()
    add_log(f'Добавлен товар: {product}')


def delete_product(product_id):
    cursor.execute(f'''
    DELETE FROM products
    WHERE id = {product_id}
    ''')
    connection.commit()


def get_products_params(*params):
    # print(params)
    cursor.execute(f'''
    SELECT {params}
    FROM products
    ''')
    return cursor.fetchall()


def get_all_products():
    cursor.execute(f'''
    SELECT *
    FROM products
    ''')
    return cursor.fetchall()


def add_admin(user_id):
    cursor.execute(f'''
    INSERT INTO admins
    VALUES (?)
    ''', (user_id,))
    connection.commit()
    add_log(f'Добален админ: id: {user_id}')


def delete_admin_from_db(admin_id):
    cursor.execute(f'''
    DELETE FROM admins
    WHERE user_id = ?
    ''', (admin_id,))
    connection.commit()
    add_log(f'Удален админ: id: {admin_id}')


def get_admins():
    values = get_all_params('admins', 'user_id')
    # values.append(5096633623)
    return values


def set_discount(product_id, discount):
    cursor.execute(f'''
    UPDATE products
    SET discount = {discount}
    WHERE id = (?)
    ''', (product_id,))
    connection.commit()


def add_purchase(user_id):
    cursor.execute(f'''
    UPDATE users
    SET purchase = purchase + 1
    WHERE id = ?
    ''', (user_id,))
    connection.commit()


def get_purchase(user_id):
    value = None
    try:
        value = get_param('users', 'purchase', 'id', user_id)
    except Exception:
        reg_new_user(user_id, username='None')
        return 0
    # if value:
    return value


def add_transaction(user_id, username, get_by_qiwi):
    cursor.execute(f'''
    INSERT INTO transactions
    VALUES (?, ?, ?, ?)
    ''', (None, user_id, username, get_by_qiwi))
    connection.commit()
